﻿using Microsoft.Expression.Interactivity.Core;
using System;
using System.ComponentModel;
using System.Windows.Input;
using ILogixxMediator;
using System.Windows;

namespace iLogixxPDFViewerControl
{
    //https://msdn.microsoft.com/en-us/library/gg405484(v=pandp.40).aspx

    public class iLogixxPDFViewModel : iLogixxPDFViewerVMBase
    {
        private string thisPdf;

        public iLogixxPDFViewModel()
        {
            

            //Set the Action Command to browse folder for PDF files.
            BrowseFileCommand = new ActionCommand(() =>
               {
                   System.Windows.Forms.OpenFileDialog fdlg = new System.Windows.Forms.OpenFileDialog
                   {
                       Filter = "PDF|*.pdf"
                   };
                   if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                   {
                       ThisPDF = fdlg.FileName;
                   }
               });
        }

        /// <BrowseFileCommand>
        /// This property used to browse the PDF file and set the ThisPDF file property
        /// </BrowseFileCommand>
        public ICommand BrowseFileCommand
        {
            get;
            private set;
        }

        /// <ThisPDF>
        /// This property to set or get the PDF file location
        /// </ThisPDF>
        public string ThisPDF
        {
            get{ return thisPdf; }

            set
            {
                if(thisPdf != value)
                {
                    thisPdf = value;                    
                    RaisePropertyChanged("ThisPDF");
                }
            }
        }                 
    }
}
