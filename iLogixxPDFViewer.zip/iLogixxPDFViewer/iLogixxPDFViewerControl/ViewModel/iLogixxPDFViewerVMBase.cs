﻿using System;
using System.Collections.Generic;
using Microsoft.Expression.Interactivity.Core;
using System.ComponentModel;
using System.Windows.Input;

namespace iLogixxPDFViewerControl
{
    public abstract class iLogixxPDFViewerVMBase : INotifyPropertyChanged
    {
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}
