﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ILogixxMediator;


namespace iLogixxPDFViewerControl
{
    public partial class AcrobatPDFReader : UserControl
    {
        private delegate void CallbackLoadNewPDFFile();
        private event EventHandler LoadNewPDF;

        private string currentPDFFilePath;
        public AcrobatPDFReader()
        {
            InitializeComponent();
            axAcroPDF.setShowToolbar(false);
            axAcroPDF.setView("FitH");
            LoadNewPDF = OnLoadNewPDF;
        }

        public string CurrentPDFFilePath
        {
            get
            {
                return currentPDFFilePath;
            }

            set
            {
                if(currentPDFFilePath != value)
                {
                    currentPDFFilePath = value;
                    LoadNewPDF(this, EventArgs.Empty);

                }
            }
        }

        protected async void OnLoadNewPDF(object source, EventArgs e)
        {
            await Task.Run(() =>
            {
                LoadNewPDFFile();
            });
        }
        private void LoadNewPDFFile()
        {
            if (axAcroPDF.InvokeRequired == true)
            {
                axAcroPDF.Invoke(new CallbackLoadNewPDFFile(LoadNewPDFFile));
            }
            else
            {
                axAcroPDF.LoadFile(currentPDFFilePath);
                axAcroPDF.src = currentPDFFilePath;
                axAcroPDF.setViewScroll("FitH", 0);

                Mediator.NotifyColleagues("LoadComplete", "Complete");
            }
        }

        public void Print()
        {
            axAcroPDF.printWithDialog();
        }
    }
}
