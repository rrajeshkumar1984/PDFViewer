﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using ILogixxMediator;
using System.ComponentModel;
using System.Windows.Input;
using System.Windows;
using System.Windows.Forms.Integration;


namespace iLogixxPDFViewerControl
{
    /// <summary>
    /// Reference: https://docs.microsoft.com/en-us/dotnet/framework/wpf/advanced/walkthrough-hosting-a-windows-forms-control-in-wpf-by-using-xaml
    /// </summary>
    public class iLogixxPDFViewerHost : WindowsFormsHost
    {

        private readonly AcrobatPDFReader pdfReader;

        /// <DependencyProperty>
        /// Register the PDFPath property which will be binded with WPF Form
        /// </DependencyProperty>
        public static readonly DependencyProperty NewPdfPathProperty = DependencyProperty.Register(
            "NewPDFPath", typeof(string), typeof(iLogixxPDFViewerHost), new PropertyMetadata(NewPdfPathPropertyChanged));


        public iLogixxPDFViewerHost()
        {
            Mediator.Register("LoadComplete", LoadComplete);

            pdfReader = new AcrobatPDFReader();
            Child = pdfReader;
        }

        ~iLogixxPDFViewerHost()
        {
            Mediator.Unregister("LoadComplete", LoadComplete);
        }
        /// <PDFPath>
        /// PDFPath property
        /// </PDFPath>
        public string NewPDFPath
        {
            get
            {
                return GetValue(NewPdfPathProperty).ToString();
            }

            set
            {
                SetValue(NewPdfPathProperty, value);
            }
        }


        public void Print()
        {
            pdfReader.Print();
        }

        public void LoadComplete(object sender)
        {
            Mediator.NotifyColleagues("SetPath", NewPDFPath);
        }
        private static void NewPdfPathPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            iLogixxPDFViewerHost host = (iLogixxPDFViewerHost)d;
            host.pdfReader.CurrentPDFFilePath = e.NewValue.ToString();            
        }
    }
}
