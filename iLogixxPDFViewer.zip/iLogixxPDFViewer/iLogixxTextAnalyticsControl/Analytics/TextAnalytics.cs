﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Linq;
using iLogixxTextAnalyticsControl.Model;
using iLogixxTextAnalyticsControl.Parser;

namespace iLogixxTextAnalyticsControl.Analytics
{
    public class TextAnalytics
    {

        private string TextfromPDF;
        
        public TextAnalytics(string path)
        {
            if (!string.IsNullOrEmpty(path))
                TextfromPDF = PDFParser.ExtractTextFromPdf(path);
        }

        public PDFToTextModel GetTextAnalyticsData()
        {
            PDFToTextModel textModel = new PDFToTextModel();

            string sTemp = TextfromPDF;         
            
            if ((sTemp !=null) && (sTemp.Length > 0))
            {
                // create the array list that will
                // be used to hold the sentences
                ArrayList al = new ArrayList();

                // split the sentences with a regular expression
                string[] splitSentences =
                    Regex.Split(sTemp, @"(?<=['""A-Za-z0-9][\.\!\?])\s+(?=[A-Z])");
                
                // loop the sentences
                for (int i = 0; i < splitSentences.Length; i++)
                {
                    // clean up the sentence one more time, trim it,
                    // and add it to the array list
                    string sSingleSentence =
                        splitSentences[i].Replace(Environment.NewLine, string.Empty);
                    al.Add(sSingleSentence.Trim());
                }

                int TotalUniqueWrdCount = GenerateUniqueWordLenght(sTemp);
                textModel.TotalUniqueWords = "Total Unique Words: " + TotalUniqueWrdCount.ToString();

                float fCharCount = GenerateCharacterCount(sTemp);
                float fWordCount = GenerateWordCount(al);
                float fWordAvgLen = (float)(fCharCount / fWordCount);
                textModel.AverageWordLength = "Average Word Length: " + fWordAvgLen.ToString();


                float fSentCount = GenerateSentenceCount(splitSentences);                                
                textModel.NumberOfSentences = "Number Of Sentences: " + fSentCount.ToString();

                
                float fSentAvgLen = (float)(fCharCount / fSentCount);
                textModel.AverageSentenceLength = "Avgerage Sentence Length: " + fSentAvgLen.ToString();


                int paragraphCount = sTemp.Split(
                        new[] { "\r\n" },
                        StringSplitOptions.RemoveEmptyEntries).Count();               
                textModel.NumberOfParagraphs = "Number Of Paragraphs: " + paragraphCount.ToString();

            }

            return textModel;
        }

#region Generate Statistics

        public ChartDataSource GenerateTopNWord()
        {
            ChartDataSource Product = new ChartDataSource();

            Hashtable frequencyWord = new Hashtable();


            string txt = TextfromPDF.ToLower();


            // Use regular expressions to replace characters
            // that are not letters or numbers with spaces.
            Regex reg_exp = new Regex("[^a-zA-Z0-9]");
            txt = reg_exp.Replace(txt, " ");

            // Split the text into words.
            string[] words = txt.Split(
                new char[] { ' ' },
                StringSplitOptions.RemoveEmptyEntries);

            foreach (string word in words)
            {
                if (frequencyWord.Contains(word))
                {
                    int wordCount = int.Parse(frequencyWord[word].ToString());
                    wordCount++;
                    frequencyWord[word] = wordCount;
                }
                else
                {
                    frequencyWord.Add(word, 1);
                }
            }

            foreach(DictionaryEntry entry in frequencyWord)
            {
                if((int)entry.Value > 5)
                {
                    Product.Add(new TopNWordModel() { Frequency = (int)entry.Value, TopNWords = entry.Key.ToString() });
                }
            }
            return Product;
        }

        public int GenerateUniqueWordLenght(string sourcetext)
        {
           
            string txt = sourcetext.ToLower();


            // Use regular expressions to replace characters
            // that are not letters or numbers with spaces.
            Regex reg_exp = new Regex("[^a-zA-Z0-9]");
            txt = reg_exp.Replace(txt, " ");

            // Split the text into words.
            string[] words = txt.Split(
                new char[] { ' ' },
                StringSplitOptions.RemoveEmptyEntries);
          
            // Use LINQ to get the unique words.
            var word_query =
                (from string word in words
                 orderby word
                 select word).Distinct();

            // Display the result.
            string[] result = word_query.ToArray();

            return result.Length;
        }
        /// <summary>
        /// Generate the total character count for
        /// the entire body of text as converted to
        /// one string
        /// </summary>
        /// <param name="allText"></param>
        /// <returns>int count of all characters</returns>
        public int GenerateCharacterCount(string allText)
        {
            int rtn = 0;


            // clean up the string by
            // removing newlines and by trimming
            // both ends
            string sTemp = allText;
            sTemp = sTemp.Replace(Environment.NewLine, string.Empty);
            sTemp = sTemp.Trim();

            // split the string into sentences 
            // using a regular expression
            string[] splitSentences =
                Regex.Split(sTemp,
                    @"(?<=['""A-Za-z0-9][\.\!\?])\s+(?=[A-Z])");

            // loop through the sentences to get character counts
            for (int cnt = 0; cnt < splitSentences.Length; cnt++)
            {
                // get the current sentence
                string sSentence = splitSentences[cnt].ToString();

                // trim it
                sSentence = sSentence.Trim();

                // convert it to a character array
                char[] sentence = sSentence.ToCharArray();

                // test each character and
                // add it to the return value
                // if it passes
                for (int i = 0; i < sentence.Length; i++)
                {
                    // make sure it is a letter, number,
                    // punctuation or whitespace before
                    // adding it to the tally
                    if (char.IsLetterOrDigit(sentence[i]) ||
                        char.IsPunctuation(sentence[i]) ||
                        char.IsWhiteSpace(sentence[i]))
                        rtn += 1;
                }
            }

            // return the final tally
            return rtn;
        }


        /// <summary>
        /// Generate a count of all words contained in the text
        /// passed into to this function is looking for
        /// an array list as an argument; the array list contains
        /// one entry for each sentence contained in the
        /// text of interest.
        /// </summary>
        /// <param name="allSentences"></param>
        /// <returns>int count of all words</returns>
        public int GenerateWordCount(ArrayList allSentences)
        {
            // declare a return value
            int rtn = 0;

            // iterate through the entire list
            // of sentences
            foreach (string sSentence in allSentences)
            {
                // define an empty space as the split
                // character
                char[] arrSplitChars = { ' ' };

                // create a string array and populate
                // it with a split on the current sentence;
                // use the string split option to remove
                // empty entries so that empty sentences do not
                // make it into the word count.
                string[] arrWords = sSentence.Split(arrSplitChars, StringSplitOptions.RemoveEmptyEntries);
                rtn += arrWords.Length;                
            }

            // return the final word count
            return rtn;
        }



        /// <summary>
        /// Return a count of all of the sentences contained in the
        /// text examined; this method is looking for a string 
        /// array containing all of the sentences; it just
        /// returns a count for the string array.
        /// </summary>
        /// <param name="allSentences"></param>
        /// <returns></returns>
        public int GenerateSentenceCount(string[] allSentences)
        {
            // create a return value
            int rtn = 0;

            // set the return value to
            // the length of the sentences array
            rtn = allSentences.Length;

            // return the count
            return rtn;
        }


#endregion


    }
}
