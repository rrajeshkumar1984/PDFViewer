﻿using Syncfusion.Windows.SampleLayout;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using iLogixxTextAnalyticsControl.Model;

namespace iLogixxTextAnalyticsControl.Chart
{
    /// <summary>
    /// Interaction logic for Histogram.xaml
    /// </summary>
    public partial class Histogram : SampleLayoutWindow
    {
        public Histogram()
        {
            InitializeComponent();
        }
        
    }

    public class TopNWordViewModel : INotifyPropertyChanged
    {
        public TopNWordViewModel()
        {           
        }

        private ChartDataSource _source = new ChartDataSource();
        public ChartDataSource DataSource
        {
            get
            {
                return _source;
            }
            set
            {
                _source = value;
                OnPropertyChanged("DataSource");
            }
        }



        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(object Property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(Property.ToString()));
            }
        }
    }

 
}
