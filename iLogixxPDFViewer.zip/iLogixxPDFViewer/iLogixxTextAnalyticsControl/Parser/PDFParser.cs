﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;

namespace iLogixxTextAnalyticsControl.Parser
{
    public static class PDFParser
    {
        public static string ExtractTextFromPdf(string path)
        {
            try
            {
                using (PdfReader reader = new PdfReader(path))
                {
                    StringBuilder text = new StringBuilder();

                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();

                        string _text = PdfTextExtractor.GetTextFromPage(reader, i, strategy);

                        _text = Encoding.UTF8.GetString(Encoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(_text)));

                        text.Append(_text);
                    }

                    return text.ToString();
                }
            }
            catch(Exception ex)
            {

            }

            return "";
        }
    }
}
