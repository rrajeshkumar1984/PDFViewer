﻿
using System;
using System.ComponentModel;
using System.Windows.Input;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using iLogixxTextAnalyticsControl.Analytics;
using iLogixxTextAnalyticsControl.Model;
using Microsoft.Expression.Interactivity.Core;
using ILogixxMediator;
using iLogixxTextAnalyticsControl.Chart;

namespace iLogixxTextAnalyticsControl.ViewModel
{
    public class PDFToTextViewModel : INotifyPropertyChanged
    {
        private event EventHandler TextAnalyticsEvent;

        public PDFToTextViewModel()
        {
            Mediator.Register("SetPath", SetPath);

            //Set the Action Command to browse folder for PDF files.
            BrowseFileCommand = new ActionCommand(() =>
            {
                System.Windows.Forms.OpenFileDialog fdlg = new System.Windows.Forms.OpenFileDialog
                {
                    Filter = "PDF|*.pdf"
                };
                if (fdlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    PDFFilePath = fdlg.FileName;
                }
            });

            TextAnalyticsEvent = OnTextAnalyticsEvent;
        }

        ~PDFToTextViewModel()
        {
            Mediator.Unregister("SetPath", SetPath);
        }

        private PDFToTextModel pdftotext;
        public PDFToTextModel PDFToText
        {
            get { return pdftotext;  }
            set
            {
                pdftotext = value;
                RaisePropertyChanged("PDFToText");
            }
        }

        private string pdffilepath;
        public string PDFFilePath
        {
            get { return pdffilepath; }
            set
            {
                if((!string.IsNullOrEmpty(value)) && (pdffilepath != value))
                {
                    pdffilepath = value;
                    TextAnalyticsEvent(this, EventArgs.Empty);
                }
            }
        }

        public ChartDataSource TopWords;
        

        public ICommand BrowseFileCommand
        {
            get;
            private set;
        }

        public void SetPath(object source)
        {
            if(!string.IsNullOrEmpty((string)source))
                PDFFilePath = (string)source;
        }
        private async void OnTextAnalyticsEvent(object sender, EventArgs e)
        {
            await Task.Run(() =>
            { StartTextPRocessing(); });

            Mediator.NotifyColleagues("ShowChartWnd", TopWords);
        }
       
        private void StartTextPRocessing()
        {           
            TextAnalytics anly = new TextAnalytics(pdffilepath);
            PDFToText = anly.GetTextAnalyticsData();
            TopWords = anly.GenerateTopNWord();           
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

