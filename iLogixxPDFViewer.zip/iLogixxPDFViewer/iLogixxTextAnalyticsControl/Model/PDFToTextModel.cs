﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using iLogixxTextAnalyticsControl.Parser;


namespace iLogixxTextAnalyticsControl.Model
{
    public class PDFToTextModel : INotifyPropertyChanged
    {
        
        private string _TotalUniqueWords;
        public string TotalUniqueWords
        {
            get { return _TotalUniqueWords; }
            set
            {
                if(_TotalUniqueWords != value)
                {
                    _TotalUniqueWords = value;
                    RaisePropertyChanged("TotalUniqueWords");
                }
            }
        }
        private string _AverageWordLength;
        public string AverageWordLength
        {
            get { return _AverageWordLength; }
            set
            {
                if (_AverageWordLength != value)
                {
                    _AverageWordLength = value;
                    RaisePropertyChanged("AverageWordLength");
                }
            }
        }
        private string _NumberOfSentences;
        public string NumberOfSentences
        {
            get { return _NumberOfSentences; }
            set
            {
                if (_NumberOfSentences != value)
                {
                    _NumberOfSentences = value;
                    RaisePropertyChanged("NumberOfSentences");
                }
            }
        }
        private string _AverageSentenceLength;
        public string AverageSentenceLength
        {
            get { return _AverageSentenceLength; }
            set
            {
                if (_AverageSentenceLength != value)
                {
                    _AverageSentenceLength = value;
                    RaisePropertyChanged("AverageSentenceLength");
                }
            }
        }
        private string _NumberOfParagraphs;
        public string NumberOfParagraphs
        {
            get { return _NumberOfParagraphs; }
            set
            {
                if (_NumberOfParagraphs != value)
                {
                    _NumberOfParagraphs = value;
                    RaisePropertyChanged("NumberOfParagraphs");
                }
            }
        }
       
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
