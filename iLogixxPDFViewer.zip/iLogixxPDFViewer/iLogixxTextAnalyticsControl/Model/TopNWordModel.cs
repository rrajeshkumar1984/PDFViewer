﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace iLogixxTextAnalyticsControl.Model
{
    public class TopNWordModel : INotifyPropertyChanged
    {
        private int frequency;
        public int Frequency
        {
            get { return frequency; }
            set
            {
                frequency = value;
                RaisePropertyChanged("Frequency");
            }
        }

        private string topNWords;
        public string TopNWords
        {
            get { return topNWords; }
            set
            {
                topNWords = value;
                RaisePropertyChanged("TopNWords");
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void RaisePropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ChartDataSource : ObservableCollection<TopNWordModel>
    {
        public ChartDataSource()
        {
        }
    }
}
